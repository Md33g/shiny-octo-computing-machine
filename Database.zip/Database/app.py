# app.py
from flask import Flask, request, redirect, url_for, Response, render_template_string
import sqlite3
import csv
import io
from datetime import datetime
import webbrowser
import threading

DB = "students.db"
app = Flask(__name__)

# ---------------- Database ---------------- #

def init_db():
    with sqlite3.connect(DB) as conn:
        c = conn.cursor()
        c.execute("""
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT,
            subject TEXT,
            register_date TEXT,
            notes TEXT
        )
        """)
        conn.commit()

def query_db(query, args=(), one=False):
    with sqlite3.connect(DB) as conn:
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        cur.execute(query, args)
        rv = cur.fetchall()
        return (rv[0] if rv else None) if one else rv

def execute_db(query, args=()):
    with sqlite3.connect(DB) as conn:
        cur = conn.cursor()
        cur.execute(query, args)
        conn.commit()
        return cur.lastrowid

# ---------------- HTML + CSS ---------------- #

INDEX_HTML = """
<!doctype html>
<html lang="ar">
<head>
  <meta charset="utf-8">
  <title>نظام تسجيل السنتر</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body { font-family: 'Segoe UI', Tahoma, Verdana, sans-serif; direction: rtl; padding: 20px; max-width: 900px; margin: auto; background-color: #f9f9f9; color: #333; }
    h1, h3 { color: #1976d2; text-align: center; }
    form { background: #fff; padding: 20px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); margin-bottom: 20px; }
    label { display: block; margin-top: 12px; font-weight: bold; }
    input, textarea { width: 100%; padding: 10px; margin-top: 6px; border: 1px solid #ccc; border-radius: 6px; box-sizing: border-box; font-size: 14px; }
    input:focus, textarea:focus { outline: none; border-color: #1976d2; box-shadow: 0 0 5px rgba(25,118,210,0.3); }
    .btn { display: inline-block; padding: 10px 16px; margin-top: 10px; margin-right: 4px; text-decoration: none; border-radius: 6px; background-color: #1976d2; color: white; font-weight: bold; transition: 0.3s; }
    .btn:hover { background-color: #1565c0; }
    .btn-danger { background-color: #d32f2f; }
    .btn-danger:hover { background-color: #b71c1c; }
    .controls { margin-top: 12px; }
  </style>
</head>
<body>
  <h1>نظام تسجيل السنتر</h1>

  <h3>إضافة طالب جديد</h3>
  <form method="post" action="/add">
    <label>الاسم (مطلوب)</label>
    <input name="name" required>

    <label>رقم التليفون</label>
    <input name="phone">

    <label>المادة</label>
    <input name="subject">

    <label>تاريخ التسجيل (اختياري)</label>
    <input name="register_date" placeholder="YYYY-MM-DD">

    <label>ملاحظات</label>
    <textarea name="notes" rows="3"></textarea>

    <div class="controls">
      <button class="btn" type="submit">حفظ الطالب</button>
      <a class="btn" href="/list">عرض الطلاب</a>
      <a class="btn" href="/export">تصدير CSV</a>
    </div>
  </form>
</body>
</html>
"""

LIST_HTML = """
<!doctype html>
<html lang="ar">
<head>
  <meta charset="utf-8">
  <title>قائمة الطلاب</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body { font-family: 'Segoe UI', Tahoma, Verdana, sans-serif; direction: rtl; padding: 20px; max-width: 1200px; margin: auto; background-color: #f9f9f9; color: #333; }
    h1 { color: #1976d2; text-align: center; margin-bottom: 20px; }
    input { padding: 8px; margin: 6px 0; }
    table { width: 100%; border-collapse: collapse; margin-top: 20px; background: #fff; border-radius: 8px; overflow: hidden; }
    th, td { border: 1px solid #ddd; padding: 10px; text-align: right; }
    th { background-color: #1976d2; color: white; }
    tr:nth-child(even) { background-color: #f2f2f2; }
    tr:hover { background-color: #e3f2fd; }
    .btn { display: inline-block; padding: 8px 12px; margin-top: 6px; margin-right: 4px; text-decoration: none; border-radius: 6px; background-color: #1976d2; color: white; font-weight: bold; transition: 0.3s; }
    .btn:hover { background-color: #1565c0; }
    .btn-danger { background-color: #d32f2f; }
    .btn-danger:hover { background-color: #b71c1c; }
    form { display: inline; }
  </style>
</head>
<body>
  <h1>قائمة الطلاب ({{ count }})</h1>

  <form method="get" action="/list" style="margin-bottom:10px">
    <input name="q" placeholder="ابحث بالاسم، التليفون، أو المادة" value="{{ q|default('') }}">
    <button class="btn" type="submit">بحث</button>
    <a class="btn" href="/">إضافة جديد</a>
    <a class="btn" href="/export">تصدير CSV</a>
  </form>

  <table>
    <thead>
      <tr>
        <th>الاسم</th><th>التليفون</th><th>المادة</th><th>تاريخ التسجيل</th><th>ملاحظات</th><th>خيارات</th>
      </tr>
    </thead>
    <tbody>
    {% for s in students %}
      <tr>
        <td>{{ s['name'] }}</td>
        <td>{{ s['phone'] or '' }}</td>
        <td>{{ s['subject'] or '' }}</td>
        <td>{{ s['register_date'] or '' }}</td>
        <td>{{ s['notes'] or '' }}</td>
        <td>
          <a class="btn" href="/edit/{{ s['id'] }}">تعديل</a>
          <form method="post" action="/delete/{{ s['id'] }}" onsubmit="return confirm('هل أنت متأكد من الحذف؟');">
            <button class="btn btn-danger" type="submit">حذف</button>
          </form>
        </td>
      </tr>
    {% endfor %}
    </tbody>
  </table>
</body>
</html>
"""

EDIT_HTML = """
<!doctype html>
<html lang="ar">
<head>
  <meta charset="utf-8">
  <title>تعديل بيانات الطالب</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body { font-family: 'Segoe UI', Tahoma, Verdana, sans-serif; direction: rtl; padding: 20px; max-width: 900px; margin: auto; background-color: #f9f9f9; color: #333; }
    h1 { color: #1976d2; text-align: center; }
    form { background: #fff; padding: 20px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); margin-bottom: 20px; }
    label { display: block; margin-top: 12px; font-weight: bold; }
    input, textarea { width: 100%; padding: 10px; margin-top: 6px; border: 1px solid #ccc; border-radius: 6px; box-sizing: border-box; font-size: 14px; }
    input:focus, textarea:focus { outline: none; border-color: #1976d2; box-shadow: 0 0 5px rgba(25,118,210,0.3); }
    .btn { display: inline-block; padding: 10px 16px; margin-top: 10px; margin-right: 4px; text-decoration: none; border-radius: 6px; background-color: #1976d2; color: white; font-weight: bold; transition: 0.3s; }
    .btn:hover { background-color: #1565c0; }
  </style>
</head>
<body>
  <h1>تعديل بيانات الطالب</h1>
  <form method="post" action="/edit/{{ student['id'] }}">
    <label>الاسم (مطلوب)</label>
    <input name="name" value="{{ student['name'] }}" required>

    <label>رقم التليفون</label>
    <input name="phone" value="{{ student['phone'] or '' }}">

    <label>المادة</label>
    <input name="subject" value="{{ student['subject'] or '' }}">

    <label>تاريخ التسجيل</label>
    <input name="register_date" value="{{ student['register_date'] }}">

    <label>ملاحظات</label>
    <textarea name="notes" rows="3">{{ student['notes'] or '' }}</textarea>

    <div class="controls">
      <button class="btn" type="submit">حفظ التعديلات</button>
      <a class="btn" href="/list">عودة للقائمة</a>
    </div>
  </form>
</body>
</html>
"""

# ---------------- Routes ---------------- #

@app.route("/")
def index():
    return render_template_string(INDEX_HTML)

@app.route("/add", methods=["POST"])
def add():
    name = request.form.get("name", "").strip()
    phone = request.form.get("phone", "").strip()
    subject = request.form.get("subject", "").strip()
    register_date = request.form.get("register_date", "").strip()
    notes = request.form.get("notes", "").strip()

    if not name:
        return "الاسم مطلوب", 400

    if not register_date:
        register_date = datetime.now().strftime("%Y-%m-%d")

    execute_db("""
        INSERT INTO students (name, phone, subject, register_date, notes)
        VALUES (?, ?, ?, ?, ?)
    """, (name, phone, subject, register_date, notes))

    return redirect(url_for("list_students"))

@app.route("/list")
def list_students():
    q = request.args.get("q", "").strip()
    if q:
        like = f"%{q}%"
        rows = query_db("""
            SELECT * FROM students
            WHERE name LIKE ? OR phone LIKE ? OR subject LIKE ?
            ORDER BY id DESC
        """, (like, like, like))
    else:
        rows = query_db("SELECT * FROM students ORDER BY id DESC")
    return render_template_string(LIST_HTML, students=rows, count=len(rows), q=q)

@app.route("/delete/<int:student_id>", methods=["POST"])
def delete(student_id):
    execute_db("DELETE FROM students WHERE id = ?", (student_id,))
    return redirect(url_for("list_students"))

@app.route("/export")
def export_csv():
    rows = query_db("SELECT * FROM students ORDER BY id DESC")
    si = io.StringIO()
    cw = csv.writer(si)
    cw.writerow(["id","name","phone","subject","register_date","notes"])
    for r in rows:
        cw.writerow([r["id"], r["name"], r["phone"], r["subject"], r["register_date"], r["notes"]])
    output = si.getvalue()
    return Response(
        output,
        mimetype="text/csv",
        headers={"Content-Disposition":"attachment;filename=students_export.csv"}
    )

@app.route("/edit/<int:student_id>", methods=["GET", "POST"])
def edit(student_id):
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        phone = request.form.get("phone", "").strip()
        subject = request.form.get("subject", "").strip()
        register_date = request.form.get("register_date", "").strip()
        notes = request.form.get("notes", "").strip()

        if not name:
            return "الاسم مطلوب", 400

        execute_db("""
            UPDATE students
            SET name=?, phone=?, subject=?, register_date=?, notes=?
            WHERE id=?
        """, (name, phone, subject, register_date, notes, student_id))

        return redirect(url_for("list_students"))
    else:
        student = query_db("SELECT * FROM students WHERE id=?", (student_id,), one=True)
        if not student:
            return "الطالب غير موجود", 404
        return render_template_string(EDIT_HTML, student=student)

# ---------------- Auto Browser ---------------- #

def open_browser():
    webbrowser.open("http://127.0.0.1:5000")

# ---------------- Main ---------------- #

if __name__ == "__main__":
    init_db()
    threading.Timer(1.5, open_browser).start()
    app.run(host="0.0.0.0", port=5000, debug=True)
